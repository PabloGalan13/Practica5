package mx.edu.itson.vistas

data class Product(var name:String,
                    var image:Int,
                    var description:String,
                    var price:Double)
